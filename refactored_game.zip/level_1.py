
import time
import os
from typing import Dict, Any

# Utility functions

def clear_screen():
    """Clears the terminal screen."""
    os.system('clear' if os.name == 'posix' else 'cls')

def display_ascii_art(art_list):
    """Displays ASCII art sequentially with a delay."""
    for art in art_list:
        clear_screen()
        print(art)
        time.sleep(0.5)

def ask_question(prompt, valid_answers):
    """Prompts the user with a question and validates the answer."""
    while True:
        answer = input(prompt).lower()
        if answer in valid_answers:
            return answer
        print("Invalid choice. Please try again.")

# Game-specific functions

def handle_riddle(riddle, valid_answers):
    """Handles a single riddle question."""
    answer = ask_question(riddle, valid_answers)
    return answer

def riddles_sequence():
    """Executes the riddles sequence."""
    riddles = [
        {
            "question": "Riddle number ONE:\n\n    what is Young yet old,\n      of pickled liver,\n        stinks of wet tobacco,\n          it\'s name gives all a shiver?\nAnswer (one word): ",
            "answers": ["youngers", "matt youngers", "chief youngers"]
        },
        {
            "question": "Riddle number TWO:\n\n    so cold and so sad,\n      you may have a reason.\n        to this place you\'ll travel,\n          for the holiday season.\nAnswer (one word): ",
            "answers": ["nowhere", "here", "stuttgart", "barracks"]
        },
        {
            "question": "Riddle number THREE:\n\n      right hand raised high,\n        an oath of 6 years.\n          a mistake there\'s no doubt,\n            only remedy is 9 or 10 ______.\nAnswer (one word): ",
            "answers": ["beers", "beer"]
        }
    ]

    for riddle in riddles:
        if not handle_riddle(riddle['question'], riddle['answers']):
            print("NO! Perhaps you need more time in the JOC! Try again in 5 seconds.")
            time.sleep(5)
            return riddles_sequence()
    print("Congratulations! You passed the riddles sequence!")
    return True

def brezlin_prompt():
    """Prompts the user to find the Brezlin."""
    brezlin_answers = ["brezlin", "get brezlin", "pretzel", "pretzels", "brez"]
    while True:
        answer = input("Before you get to work, there's still one more thing you need. What is it? Answer: ").lower()
        if answer in brezlin_answers:
            print("Excellent, mein Brezlin. Take this Brezlin with you, you'll need it.")
            print(r"""
               __       __
             .'  `'. .'`  '.
            |  .--;   ;--.  |
            |  (  /   \  )  |
             \  ;` /^\ `;  /
              :` .'._.'. `;
              `-'.___.`-'
            """)
            time.sleep(2)
            return True
        else:
            print("Incorrect. Try again.")

# Main game function

def level_1():
    """Handles Level 1 of the game."""
    clear_screen()
    print("It's 5 AM - still dark outside...")
    time.sleep(1)
    print("You're almost at work.")
    time.sleep(1)
    print("Before you get to work, there's still one more thing you need.")

    if brezlin_prompt():
        print("Your day continues...")
        print("Time for the dreaded Daily Update Brief...")

        attend = ask_question("Do you attend the Daily Update Brief? (yes/no): ", ["yes", "no"])
        if attend == "yes":
            print("You chose correctly!")
            riddles_sequence()
        else:
            print("You skipped lunch and feel regret.")
            riddles_sequence()

if __name__ == "__main__":
    level_1()
